import './bootstrap';

const html = document.documentElement;
const storedTheme = localStorage.getItem('theme');
const systemDark = window.matchMedia('(prefers-color-scheme: dark)').matches;

if (storedTheme === 'dark' || (!storedTheme && systemDark)) {
    html.classList.add('dark');
}

const faDigits = (value) => String(value).replace(/\d/g, (digit) => '۰۱۲۳۴۵۶۷۸۹'[Number(digit)]);
const pad = (value) => String(value).padStart(2, '0');

const gregorianToJalali = (gy, gm, gd) => {
    const monthDays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    let gDayNo = 365 * (gy - 1600) + Math.floor((gy - 1597) / 4)
        - Math.floor((gy - 1501) / 100) + Math.floor((gy - 1201) / 400);

    for (let i = 0; i < gm - 1; i += 1) gDayNo += monthDays[i];
    const leap = (gy % 4 === 0 && gy % 100 !== 0) || gy % 400 === 0;
    if (gm > 2 && leap) gDayNo += 1;
    gDayNo += gd - 1;

    let jDayNo = gDayNo - 79;
    const jNp = Math.floor(jDayNo / 12053);
    jDayNo %= 12053;
    let jy = 979 + 33 * jNp + 4 * Math.floor(jDayNo / 1461);
    jDayNo %= 1461;
    if (jDayNo >= 366) {
        jy += Math.floor((jDayNo - 1) / 365);
        jDayNo = (jDayNo - 1) % 365;
    }

    const jMonthDays = [31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29];
    let jm = 0;
    while (jm < 11 && jDayNo >= jMonthDays[jm]) {
        jDayNo -= jMonthDays[jm];
        jm += 1;
    }

    return [jy, jm + 1, jDayNo + 1];
};

const jalaliToGregorian = (jy, jm, jd) => {
    let year = jy - 979;
    let jDayNo = 365 * year + Math.floor(year / 33) * 8 + Math.floor(((year % 33) + 3) / 4);
    for (let i = 0; i < jm - 1; i += 1) jDayNo += i < 6 ? 31 : 30;
    jDayNo += jd - 1;

    let gDayNo = jDayNo + 79;
    let gy = 1600 + 400 * Math.floor(gDayNo / 146097);
    gDayNo %= 146097;
    let leap = true;

    if (gDayNo >= 36525) {
        gDayNo -= 1;
        gy += 100 * Math.floor(gDayNo / 36524);
        gDayNo %= 36524;
        if (gDayNo >= 365) gDayNo += 1;
        else leap = false;
    }

    gy += 4 * Math.floor(gDayNo / 1461);
    gDayNo %= 1461;
    if (gDayNo >= 366) {
        leap = false;
        gDayNo -= 1;
        gy += Math.floor(gDayNo / 365);
        gDayNo %= 365;
    }

    const monthDays = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    let gm = 0;
    while (gDayNo >= monthDays[gm]) {
        gDayNo -= monthDays[gm];
        gm += 1;
    }

    return [gy, gm + 1, gDayNo + 1];
};

const persianMonthNames = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
const persianWeekdays = ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'];
const fullWeekdays = ['یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه', 'شنبه'];

const jalaliMonthLength = (jy, jm) => {
    const [gy, gm, gd] = jalaliToGregorian(jy, jm, 1);
    const next = jm === 12 ? jalaliToGregorian(jy + 1, 1, 1) : jalaliToGregorian(jy, jm + 1, 1);
    return Math.round((Date.UTC(next[0], next[1] - 1, next[2]) - Date.UTC(gy, gm - 1, gd)) / 86400000);
};

const dateLabel = (gy, gm, gd) => {
    const [jy, jm, jd] = gregorianToJalali(gy, gm, gd);
    const weekday = fullWeekdays[new Date(Date.UTC(gy, gm - 1, gd)).getUTCDay()];
    return `${weekday}، ${faDigits(jd)} ${persianMonthNames[jm - 1]} ${faDigits(jy)}`;
};

const initPersianDatePicker = () => {
    let activeField = null;
    let visibleYear;
    let visibleMonth;

    const modal = document.createElement('div');
    modal.className = 'persian-calendar-modal hidden';
    modal.innerHTML = `
        <div class="persian-calendar-backdrop" data-calendar-close></div>
        <div class="persian-calendar-dialog" role="dialog" aria-modal="true" aria-label="انتخاب تاریخ">
            <div class="flex items-center justify-between border-b border-gray-100 p-4 dark:border-gray-700">
                <button type="button" class="calendar-nav" data-calendar-next aria-label="ماه بعد">‹</button>
                <div class="text-center">
                    <div class="font-extrabold text-gray-900 dark:text-white" data-calendar-title></div>
                    <div class="mt-1 text-xs text-gray-500">تقویم هجری شمسی</div>
                </div>
                <button type="button" class="calendar-nav" data-calendar-prev aria-label="ماه قبل">›</button>
            </div>
            <div class="p-4">
                <div class="grid grid-cols-7 gap-1 text-center text-xs font-bold text-gray-400" data-calendar-weekdays></div>
                <div class="mt-2 grid grid-cols-7 gap-1" data-calendar-days></div>
            </div>
            <div class="flex items-center justify-between border-t border-gray-100 p-3 dark:border-gray-700">
                <button type="button" class="text-sm font-semibold text-red-600" data-calendar-clear>پاک‌کردن</button>
                <button type="button" class="text-sm font-semibold text-primary" data-calendar-today>امروز</button>
            </div>
        </div>`;
    document.body.appendChild(modal);

    modal.querySelector('[data-calendar-weekdays]').innerHTML = persianWeekdays.map((day) => `<span class="py-2">${day}</span>`).join('');

    const close = () => {
        modal.classList.add('hidden');
        document.body.classList.remove('overflow-hidden');
        activeField = null;
    };

    const setValue = (gy, gm, gd) => {
        if (!activeField) return;
        const hidden = activeField.querySelector('[data-persian-date-value]');
        const label = activeField.querySelector('[data-persian-date-label]');
        hidden.value = `${gy}-${pad(gm)}-${pad(gd)}`;
        label.textContent = dateLabel(gy, gm, gd);
        activeField.querySelector('[data-persian-date-trigger]')?.classList.remove('text-gray-400');
        hidden.dispatchEvent(new Event('change', { bubbles: true }));
        close();
    };

    const render = () => {
        modal.querySelector('[data-calendar-title]').textContent = `${persianMonthNames[visibleMonth - 1]} ${faDigits(visibleYear)}`;
        const daysNode = modal.querySelector('[data-calendar-days]');
        const [firstGy, firstGm, firstGd] = jalaliToGregorian(visibleYear, visibleMonth, 1);
        const firstDayIndex = (new Date(Date.UTC(firstGy, firstGm - 1, firstGd)).getUTCDay() + 1) % 7;
        const monthLength = jalaliMonthLength(visibleYear, visibleMonth);
        const selectedValue = activeField?.querySelector('[data-persian-date-value]')?.value;
        const today = new Date();
        const todayKey = `${today.getFullYear()}-${pad(today.getMonth() + 1)}-${pad(today.getDate())}`;
        let output = '<span></span>'.repeat(firstDayIndex);

        for (let day = 1; day <= monthLength; day += 1) {
            const [gy, gm, gd] = jalaliToGregorian(visibleYear, visibleMonth, day);
            const key = `${gy}-${pad(gm)}-${pad(gd)}`;
            const selected = key === selectedValue;
            const isToday = key === todayKey;
            output += `<button type="button" class="calendar-day ${selected ? 'is-selected' : ''} ${isToday ? 'is-today' : ''}" data-calendar-day="${day}">${faDigits(day)}</button>`;
        }

        daysNode.innerHTML = output;
        daysNode.querySelectorAll('[data-calendar-day]').forEach((button) => {
            button.addEventListener('click', () => {
                const [gy, gm, gd] = jalaliToGregorian(visibleYear, visibleMonth, Number(button.dataset.calendarDay));
                setValue(gy, gm, gd);
            });
        });
    };

    document.querySelectorAll('[data-persian-date-field]').forEach((field) => {
        field.querySelector('[data-persian-date-trigger]')?.addEventListener('click', () => {
            activeField = field;
            const value = field.querySelector('[data-persian-date-value]').value;
            let source = new Date();
            if (/^\d{4}-\d{2}-\d{2}$/.test(value)) {
                const [gy, gm, gd] = value.split('-').map(Number);
                source = new Date(Date.UTC(gy, gm - 1, gd));
            }
            [visibleYear, visibleMonth] = gregorianToJalali(source.getUTCFullYear(), source.getUTCMonth() + 1, source.getUTCDate());
            modal.classList.remove('hidden');
            document.body.classList.add('overflow-hidden');
            render();
        });
    });

    modal.querySelectorAll('[data-calendar-close]').forEach((button) => button.addEventListener('click', close));
    modal.querySelector('[data-calendar-prev]').addEventListener('click', () => {
        visibleMonth -= 1;
        if (visibleMonth < 1) { visibleMonth = 12; visibleYear -= 1; }
        render();
    });
    modal.querySelector('[data-calendar-next]').addEventListener('click', () => {
        visibleMonth += 1;
        if (visibleMonth > 12) { visibleMonth = 1; visibleYear += 1; }
        render();
    });
    modal.querySelector('[data-calendar-today]').addEventListener('click', () => {
        const today = new Date();
        setValue(today.getFullYear(), today.getMonth() + 1, today.getDate());
    });
    modal.querySelector('[data-calendar-clear]').addEventListener('click', () => {
        if (!activeField) return;
        activeField.querySelector('[data-persian-date-value]').value = '';
        activeField.querySelector('[data-persian-date-label]').textContent = 'انتخاب تاریخ';
        activeField.querySelector('[data-persian-date-trigger]')?.classList.add('text-gray-400');
        close();
    });
};

const initWeeklySchedule = () => {
    const dayCards = [...document.querySelectorAll('[data-weekly-day]')];
    if (!dayCards.length) return;

    const timeToMinutes = (time) => {
        const parts = String(time || '').split(':').map(Number);
        return parts.length === 2 && parts.every(Number.isFinite) ? parts[0] * 60 + parts[1] : null;
    };
    const minutesToTime = (minutes) => `${pad(Math.floor(minutes / 60))}:${pad(minutes % 60)}`;

    const currentCapacities = (card) => {
        const result = {};
        card.querySelectorAll('[data-slot-capacity]').forEach((input) => {
            result[input.dataset.slotTime] = Number(input.value || 1);
        });
        return result;
    };

    const renderDay = (card, forcedCapacities = null) => {
        const enabled = card.querySelector('[data-day-enabled]').checked;
        const controls = card.querySelectorAll('[data-day-control]');
        const content = card.querySelector('[data-day-content]');
        const slotsNode = card.querySelector('[data-day-slots]');
        controls.forEach((control) => { control.disabled = !enabled; });
        content.classList.toggle('opacity-50', !enabled);

        if (!enabled) {
            slotsNode.innerHTML = '<div class="col-span-full rounded-xl border border-dashed border-gray-200 px-4 py-5 text-center text-sm text-gray-400 dark:border-gray-700">این روز تعطیل است.</div>';
            return;
        }

        const weekday = card.dataset.weekday;
        const start = timeToMinutes(card.querySelector('[data-day-start]').value);
        const end = timeToMinutes(card.querySelector('[data-day-end]').value);
        const duration = Number(card.querySelector('[data-day-duration]').value);
        const defaultCapacity = Number(card.querySelector('[data-day-capacity]').value || 1);
        const previous = forcedCapacities || currentCapacities(card) || {};

        if (start === null || end === null || end <= start || !duration) {
            slotsNode.innerHTML = '<div class="col-span-full rounded-xl bg-amber-50 px-4 py-3 text-sm text-amber-700 dark:bg-amber-900/20 dark:text-amber-300">ساعت شروع و پایان را درست وارد کنید.</div>';
            return;
        }

        if ((end - start) % duration !== 0) {
            slotsNode.innerHTML = '<div class="col-span-full rounded-xl bg-red-50 px-4 py-3 text-sm text-red-700 dark:bg-red-900/20 dark:text-red-300">بازه زمانی باید دقیقاً بر مدت اسلات بخش‌پذیر باشد.</div>';
            return;
        }

        const rows = [];
        for (let cursor = start; cursor + duration <= end; cursor += duration) {
            const startTime = minutesToTime(cursor);
            const endTime = minutesToTime(cursor + duration);
            const capacity = previous[startTime] ?? defaultCapacity;
            rows.push(`
                <label class="slot-capacity-card">
                    <span class="slot-time" dir="ltr">${faDigits(startTime)} تا ${faDigits(endTime)}</span>
                    <span class="text-xs text-gray-500">ظرفیت خودرو</span>
                    <span class="flex items-center gap-2">
                        <button type="button" class="slot-step" data-capacity-minus aria-label="کاهش ظرفیت">−</button>
                        <input type="number" min="1" max="100" value="${capacity}" name="days[${weekday}][slot_capacities][${startTime}]" class="slot-capacity-input" data-slot-capacity data-slot-time="${startTime}">
                        <button type="button" class="slot-step" data-capacity-plus aria-label="افزایش ظرفیت">+</button>
                    </span>
                </label>`);
        }
        slotsNode.innerHTML = rows.join('');

        slotsNode.querySelectorAll('[data-capacity-minus], [data-capacity-plus]').forEach((button) => {
            button.addEventListener('click', () => {
                const input = button.parentElement.querySelector('[data-slot-capacity]');
                const change = button.hasAttribute('data-capacity-plus') ? 1 : -1;
                input.value = Math.max(1, Math.min(100, Number(input.value || 1) + change));
            });
        });
    };

    dayCards.forEach((card) => {
        let initial = {};
        try { initial = JSON.parse(card.dataset.initialCapacities || '{}'); } catch (_) { initial = {}; }
        card.querySelectorAll('[data-day-enabled], [data-day-start], [data-day-end], [data-day-duration], [data-day-capacity]').forEach((input) => {
            input.addEventListener('change', () => renderDay(card));
            input.addEventListener('input', () => {
                if (input.matches('[data-day-capacity]')) return;
                renderDay(card);
            });
        });
        card.querySelector('[data-apply-default]')?.addEventListener('click', () => {
            const capacity = Number(card.querySelector('[data-day-capacity]').value || 1);
            card.querySelectorAll('[data-slot-capacity]').forEach((input) => { input.value = capacity; });
        });
        card.querySelector('[data-copy-day]')?.addEventListener('click', () => {
            const enabled = card.querySelector('[data-day-enabled]').checked;
            const capacities = currentCapacities(card);
            dayCards.forEach((target) => {
                if (target === card) return;
                target.querySelector('[data-day-enabled]').checked = enabled;
                target.querySelector('[data-day-start]').value = card.querySelector('[data-day-start]').value;
                target.querySelector('[data-day-end]').value = card.querySelector('[data-day-end]').value;
                target.querySelector('[data-day-duration]').value = card.querySelector('[data-day-duration]').value;
                target.querySelector('[data-day-capacity]').value = card.querySelector('[data-day-capacity]').value;
                renderDay(target, capacities);
            });
        });
        renderDay(card, initial);
    });
};

const initSlotPicker = () => {
    const select = document.querySelector('[data-booking-slot-select]');
    const cards = document.querySelectorAll('[data-booking-slot-card]');
    if (!select || !cards.length) return;
    cards.forEach((card) => card.addEventListener('click', () => {
        select.value = card.dataset.slotId;
        cards.forEach((item) => item.classList.toggle('is-selected', item === card));
        select.dispatchEvent(new Event('change', { bubbles: true }));
    }));
};

document.addEventListener('DOMContentLoaded', () => {
    const sidebar = document.querySelector('[data-panel-sidebar]');
    const overlay = document.querySelector('[data-sidebar-overlay]');

    const setSidebar = (open) => {
        if (!sidebar || !overlay) return;
        sidebar.classList.toggle('translate-x-full', !open);
        sidebar.classList.toggle('translate-x-0', open);
        overlay.classList.toggle('hidden', !open);
        document.body.classList.toggle('overflow-hidden', open);
    };

    document.querySelectorAll('[data-sidebar-open]').forEach((button) => button.addEventListener('click', () => setSidebar(true)));
    document.querySelectorAll('[data-sidebar-close], [data-sidebar-overlay]').forEach((button) => button.addEventListener('click', () => setSidebar(false)));

    document.querySelectorAll('[data-theme-toggle]').forEach((button) => {
        button.addEventListener('click', () => {
            html.classList.toggle('dark');
            localStorage.setItem('theme', html.classList.contains('dark') ? 'dark' : 'light');
        });
    });

    document.querySelectorAll('[data-dropdown-toggle]').forEach((button) => {
        button.addEventListener('click', (event) => {
            event.stopPropagation();
            document.getElementById(button.dataset.dropdownToggle)?.classList.toggle('hidden');
        });
    });

    document.addEventListener('click', () => document.querySelectorAll('[data-dropdown-menu]').forEach((menu) => menu.classList.add('hidden')));

    document.querySelectorAll('[data-confirm]').forEach((element) => {
        element.addEventListener('click', (event) => {
            if (!window.confirm(element.dataset.confirm || 'آیا مطمئن هستید؟')) event.preventDefault();
        });
    });

    document.querySelectorAll('[data-password-toggle]').forEach((button) => {
        button.addEventListener('click', () => {
            const input = document.getElementById(button.dataset.passwordToggle);
            if (input) input.type = input.type === 'password' ? 'text' : 'password';
        });
    });

    const activateAuthTab = (tab) => {
        document.querySelectorAll('[data-auth-tab]').forEach((button) => {
            const active = button.dataset.authTab === tab;
            button.classList.toggle('bg-primary', active);
            button.classList.toggle('text-white', active);
            button.classList.toggle('text-gray-600', !active);
            button.classList.toggle('dark:text-gray-300', !active);
        });
        document.querySelectorAll('[data-auth-panel]').forEach((panel) => panel.classList.toggle('hidden', panel.dataset.authPanel !== tab));
    };
    document.querySelectorAll('[data-auth-tab]').forEach((button) => button.addEventListener('click', () => activateAuthTab(button.dataset.authTab)));
    activateAuthTab(document.querySelector('[data-auth-tabs]')?.dataset.defaultTab || 'password');

    initPersianDatePicker();
    initWeeklySchedule();
    initSlotPicker();
});
