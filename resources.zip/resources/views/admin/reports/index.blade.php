@extends('layouts.admin')
@section('title', 'گزارش‌ها')
@section('page-title', 'گزارش‌های مدیریتی')
@section('content')
<div class="mb-6 flex flex-wrap items-center justify-between gap-3"><div><h1 class="text-2xl font-extrabold text-gray-900 dark:text-white">گزارش عملکرد پلتفرم</h1><p class="mt-1 text-sm text-gray-500">تحلیل رزرو، درآمد و رشد سامانه</p></div>
<form class="flex flex-wrap gap-2"><input type="date" name="from" value="{{ $from->format('Y-m-d') }}" class="form-control w-auto"><input type="date" name="to" value="{{ $to->format('Y-m-d') }}" class="form-control w-auto"><button class="btn-primary">اعمال بازه</button></form></div>
<div class="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
<x-panel.stat-card label="کل رزرو" :value="number_format($summary['bookings'])" icon="bookings"/>
<x-panel.stat-card label="رزرو تکمیل‌شده" :value="number_format($summary['completed'])" icon="check" tone="green"/>
<x-panel.stat-card label="لغو و رد" :value="number_format($summary['cancelled'])" icon="close" tone="red"/>
<x-panel.stat-card label="درآمد" :value="number_format($summary['revenue']).' ریال'" icon="finance" tone="green"/>
<x-panel.stat-card label="کاربر جدید" :value="number_format($summary['new_users'])" icon="users" tone="blue"/>
<x-panel.stat-card label="کارواش جدید" :value="number_format($summary['new_car_washes'])" icon="carwash" tone="violet"/>
</div>
<div class="mt-6 grid gap-6 xl:grid-cols-2">
<section class="panel-card"><div class="panel-card-header"><h2 class="font-bold">روند رزروها</h2></div><div class="panel-card-body h-80"><canvas id="reportChart"></canvas></div></section>
<section class="panel-card"><div class="panel-card-header"><h2 class="font-bold">کارواش‌های برتر</h2></div><div class="overflow-x-auto"><table class="data-table"><thead><tr><th>کارواش</th><th>رزرو</th><th>ارزش رزروهای تکمیل</th></tr></thead><tbody>@forelse($topCarWashes as $wash)<tr><td class="font-semibold">{{ $wash->name }}</td><td>{{ number_format($wash->bookings_count) }}</td><td>{{ number_format($wash->revenue) }} ریال</td></tr>@empty<tr><td colspan="3"><x-empty-state title="داده‌ای در این بازه نیست" icon="reports"/></td></tr>@endforelse</tbody></table></div></section>
</div>
@endsection
@push('scripts')
<script>document.addEventListener('DOMContentLoaded',()=>{const c=document.getElementById('reportChart');if(!c||typeof Chart==='undefined')return;new Chart(c,{type:'bar',data:{labels:@json($daily->pluck('day')),datasets:[{data:@json($daily->pluck('bookings')),backgroundColor:'#ff8229',borderRadius:8}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true,ticks:{precision:0}}}}});});</script>
@endpush
