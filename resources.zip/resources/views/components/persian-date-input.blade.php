@props([
    'name',
    'value' => null,
    'label' => null,
    'placeholder' => 'انتخاب تاریخ',
    'required' => false,
    'min' => null,
    'max' => null,
])
@php
    $resolvedValue = old($name, $value);
    $displayValue = $resolvedValue ? \App\Support\PersianDate::human($resolvedValue) : '';
    $inputId = $attributes->get('id') ?: 'persian-date-'.preg_replace('/[^a-zA-Z0-9_-]/', '-', $name).'-'.uniqid();
@endphp
<div class="persian-date-field" data-persian-date-field>
    @if($label)
        <label for="{{ $inputId }}-display" class="form-label">{{ $label }}</label>
    @endif
    <input
        type="hidden"
        id="{{ $inputId }}"
        name="{{ $name }}"
        value="{{ $resolvedValue }}"
        data-persian-date-value
        @if($required) required @endif
        @if($min) min="{{ $min }}" @endif
        @if($max) max="{{ $max }}" @endif
    >
    <button
        type="button"
        id="{{ $inputId }}-display"
        data-persian-date-trigger
        class="form-control flex items-center justify-between gap-3 text-right {{ $displayValue ? '' : 'text-gray-400' }}"
        aria-haspopup="dialog"
    >
        <span data-persian-date-label>{{ $displayValue ?: $placeholder }}</span>
        <x-icon name="schedule" class="h-4 w-4 shrink-0 text-gray-400"/>
    </button>
</div>
